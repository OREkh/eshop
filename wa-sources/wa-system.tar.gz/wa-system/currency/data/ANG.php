<?php

return array(
    'code' => 'ANG',
    'sign' => 'f',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Netherlands Antillean guilder',
    'name' => array(
        array('', ''),
        'NAƒ',
        'NAf',
        'ƒ',
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);