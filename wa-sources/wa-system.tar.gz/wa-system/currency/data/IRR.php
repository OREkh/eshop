<?php

return array(
    'code' => 'IRR',
    'sign' => 'rial',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Iranian rial',
    'name' => array(
        array('rial', 'rials'),
    ),
    'frac_name' => array(
    )
);