<?php
/** List of regions for address field editor */
class webasystProfileRegionsController extends webasystBackendRegionsController
{
}

