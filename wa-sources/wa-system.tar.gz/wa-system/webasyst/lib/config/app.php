<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.7.1',
    'critical'=>'1.7.1',
    'vendor' => 'webasyst',
);
